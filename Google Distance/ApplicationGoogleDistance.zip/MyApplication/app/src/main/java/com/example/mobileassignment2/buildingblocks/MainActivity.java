package com.example.mobileassignment2.buildingblocks;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    String DistanceResult;
    String DurationResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activitiy_main);
        Reset();
    }

    public void Reset(){
        DistanceResult = "";
        DurationResult = "";
        TextView Distance_Output = (TextView) findViewById(R.id.DistanceResult);
        TextView Duration_Output = (TextView) findViewById(R.id.DurationResult);
        Distance_Output.setText("Distance: " + DistanceResult);
        Duration_Output.setText("Duration: " + DurationResult);
    }

    public void SearchDistanceCommand(View view) {
        EditText Start_Location = (EditText) findViewById(R.id.StartLocation);
        EditText Goal_Location = (EditText) findViewById(R.id.GoalLocation);
        Reset();

        if(Start_Location.getText().toString().isEmpty()|| Goal_Location.getText().toString().isEmpty()){
            Toast MissingTextErrorHandle = Toast.makeText(getApplicationContext(), "You need to input data into both fields!", Toast.LENGTH_SHORT);
            MissingTextErrorHandle.show();
        }
        else
        {
            new AsyncTaskParseJson().execute();
        }
    }

    public class AsyncTaskParseJson extends AsyncTask<String, String, String> {

        EditText Start_Location = (EditText) findViewById(R.id.StartLocation);
        EditText Goal_Location = (EditText) findViewById(R.id.GoalLocation);

        String FormattedStartLocation = Start_Location.getText().toString().replaceAll(" ", "+");
        String FormattedGoalLocation = Goal_Location.getText().toString().replaceAll(" ", "+");

        String yourServiceUrl = "https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins=" + FormattedStartLocation + "&destinations=" + FormattedGoalLocation
                + "&key=AIzaSyA609lXN9_qcwJiHpo02CTuB0oXGxDDumo";

        @Override
        protected void onPreExecute() {
            ProgressBar spinner;
            spinner = (ProgressBar) findViewById(R.id.progressBar1);
            spinner.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(String... arg0) {
            try {

                httpConnect jParser = new httpConnect();
                String json = jParser.getJSONFromUrl(yourServiceUrl);
                JSONObject object = new JSONObject(json);

                //contains ALL routes
                JSONArray array = object.getJSONArray("rows");
                // Get the first route
                JSONObject route = array.getJSONObject(0);
                // Take all elements
                JSONArray elements = route.getJSONArray("elements");
                //Tale First Element
                JSONObject element = elements.getJSONObject(0);

                // Get Duration
                JSONObject durationObject = element.getJSONObject("duration");
                String duration = durationObject.getString("text");
                DurationResult = duration;

                // Get Distance
                JSONObject distanceObject = element.getJSONObject("distance");
                String distance = distanceObject.getString("text");
                DistanceResult = distance;

            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String strFromDoInBg) {

            if(DistanceResult == null || DurationResult == null){
                Toast ResultErrorHandle = Toast.makeText(getApplicationContext(), "We could not find any results! Sorry!", Toast.LENGTH_SHORT);
                ResultErrorHandle.show();
            }

            ProgressBar spinner;
            spinner = (ProgressBar) findViewById(R.id.progressBar1);
            spinner.setVisibility(View.INVISIBLE);

            TextView Distance_Output = (TextView) findViewById(R.id.DistanceResult);
            Distance_Output.setText("Distance: " + DistanceResult);

            TextView Duration_Output = (TextView) findViewById(R.id.DurationResult);
            Duration_Output.setText("Duration: " + DurationResult);
        }
    }
}

